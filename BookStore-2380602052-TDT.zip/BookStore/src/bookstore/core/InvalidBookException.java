package bookstore.core;

public class InvalidBookException extends Exception{
    public InvalidBookException(String msg) {
        super(msg);
    }

}
